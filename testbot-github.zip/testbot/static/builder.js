(function () {
  const cfg = window.BUILDER;
  const tg = window.Telegram && window.Telegram.WebApp;
  if (tg) { try { tg.ready(); tg.expand(); } catch (e) {} }
  const dev = new URLSearchParams(location.search).get('dev_user');
  const L = ['A', 'B', 'C', 'D', 'E'];
  const ICON_KEY = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="7.5" cy="15.5" r="4.5"/><path d="m10.7 12.3 9.3-9.3M17 6l3 3M14 9l2 2"/></svg>';
  const ICON_PEN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
  const root = document.getElementById('builder');
  const sendBtn = document.getElementById('send');
  const keypad = document.getElementById('keypad');

  let state = { title: '', n: 30, options: 4, math: false, keys: [] };
  let activeInput = null;
  if (cfg.initial) {
    state.title = cfg.initial.title; state.options = cfg.initial.options; state.math = !!cfg.initial.math_keyboard;
    state.n = cfg.initial.answers.length;
    state.keys = cfg.initial.answers.map(a => a.type === 'open' ? { type: 'open', text: a.values.join('; ') } : { type: 'choice', value: a.value });
  }
  while (state.keys.length < state.n) state.keys.push({ type: 'choice', value: null });

  function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.style.display = 'block';
    setTimeout(() => (t.style.display = 'none'), 3200);
  }
  function done(k) { return k.type === 'open' ? !!(k.text || '').trim() : !!k.value; }
  function progress() {
    const n = state.keys.slice(0, state.n).filter(done).length;
    document.getElementById('prog-bar').style.width = (n * 100 / state.n) + '%';
    document.getElementById('prog-txt').textContent = n + ' / ' + state.n;
    state.keys.slice(0, state.n).forEach((k, i) => {
      const el = document.getElementById('num' + i);
      if (el) el.classList.toggle('done', done(k));
    });
  }

  function render() {
    let h = '<div class="head"><div class="top"><div class="icon">' + ICON_KEY + '</div><div style="flex:1;min-width:0">' +
      '<input class="title-input" id="title" maxlength="100" placeholder="Test nomi"><div class="sub">To\'g\'ri javoblarni belgilang</div></div></div>' +
      '<div class="chips">' +
      '<button class="chip ' + (state.math ? 'on' : 'blue') + '" id="mathChip">Matematik klaviatura</button>' +
      '<span class="chip"><input type="number" id="count" min="1" max="200" value="' + state.n + '" style="width:44px;background:transparent;border:0;color:inherit;font:inherit;outline:0;text-align:right"> ta savol</span>' +
      '<button class="chip" id="optChip">' + (state.options === 5 ? 'A–E' : 'A–D') + '</button>' +
      '</div><div class="progress"><div class="bar"><i id="prog-bar" style="width:0"></i></div><span id="prog-txt"></span></div></div>' +
      '<p class="hint">Variantni tanlang yoki <b>Ochiq javob</b> yozing. Ochiq javobga bir nechta ekvivalent kiritish mumkin (masalan: <b>1/2; 0.5</b>). Katta-kichik harf farq qilmaydi.</p><div class="rows">';
    for (let i = 0; i < state.n; i++) {
      const k = state.keys[i];
      h += '<div class="row"><div class="num" id="num' + i + '">' + (i + 1) + '</div>';
      for (let j = 0; j < state.options; j++) {
        const v = L[j].toLowerCase();
        h += '<button class="opt ' + (k.type === 'choice' && k.value === v ? 'sel' : '') + '" data-i="' + i + '" data-v="' + v + '">' + L[j] + '</button>';
      }
      h += '<div class="br"></div><button class="open-btn ' + (k.type === 'open' ? 'sel' : '') + '" data-open="' + i + '">' + ICON_PEN + 'Ochiq javob</button>';
      h += '<input class="open-input" id="in' + i + '" data-in="' + i + '" style="display:' + (k.type === 'open' ? 'block' : 'none') + '" placeholder="To\'g\'ri javob (1/2; 0.5)" autocomplete="off">';
      h += '</div>';
    }
    h += '</div>';
    root.innerHTML = h;
    document.getElementById('title').value = state.title;
    state.keys.slice(0, state.n).forEach((k, i) => { if (k.type === 'open') document.getElementById('in' + i).value = k.text || ''; });

    document.getElementById('title').addEventListener('input', e => (state.title = e.target.value));
    document.getElementById('mathChip').addEventListener('click', () => { state.math = !state.math; render(); });
    document.getElementById('optChip').addEventListener('click', () => {
      state.options = state.options === 4 ? 5 : 4;
      state.keys.forEach(k => { if (k.type === 'choice' && k.value === 'e' && state.options === 4) k.value = null; });
      render();
    });
    document.getElementById('count').addEventListener('change', e => {
      const v = Math.max(1, Math.min(200, parseInt(e.target.value, 10) || 1));
      state.n = v;
      while (state.keys.length < v) state.keys.push({ type: 'choice', value: null });
      render();
    });
    root.querySelectorAll('.opt').forEach(b => b.addEventListener('click', () => {
      const i = +b.dataset.i;
      const k = state.keys[i];
      state.keys[i] = k.type === 'choice' && k.value === b.dataset.v ? { type: 'choice', value: null } : { type: 'choice', value: b.dataset.v };
      root.querySelectorAll('.opt[data-i="' + i + '"]').forEach(x => x.classList.toggle('sel', state.keys[i].value === x.dataset.v));
      root.querySelector('.open-btn[data-open="' + i + '"]').classList.remove('sel');
      document.getElementById('in' + i).style.display = 'none';
      progress();
    }));
    root.querySelectorAll('.open-btn').forEach(b => b.addEventListener('click', () => {
      const i = +b.dataset.open;
      state.keys[i] = { type: 'open', text: '' };
      root.querySelectorAll('.opt[data-i="' + i + '"]').forEach(x => x.classList.remove('sel'));
      b.classList.add('sel');
      const inp = document.getElementById('in' + i);
      inp.style.display = 'block'; inp.value = ''; inp.focus();
      progress();
    }));
    root.querySelectorAll('.open-input').forEach(inp => {
      inp.addEventListener('input', () => { state.keys[+inp.dataset.in].text = inp.value; progress(); });
      inp.addEventListener('focus', () => { activeInput = inp; if (state.math) keypad.classList.add('show'); });
    });
    progress();
  }

  ['1','2','3','4','5','6','7','8','9','0','.','/','-',';','⌫'].forEach(ch => {
    const b = document.createElement('button');
    b.textContent = ch;
    b.addEventListener('mousedown', e => e.preventDefault());
    b.addEventListener('click', () => {
      if (!activeInput) return;
      activeInput.value = ch === '⌫' ? activeInput.value.slice(0, -1) : activeInput.value + ch;
      activeInput.dispatchEvent(new Event('input'));
    });
    keypad.appendChild(b);
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.keypad') && !e.target.closest('.open-input')) keypad.classList.remove('show');
  });

  sendBtn.addEventListener('click', async () => {
    const title = state.title.trim();
    if (!title) return toast('Test nomini yozing');
    const keys = [];
    for (let i = 0; i < state.n; i++) {
      const k = state.keys[i];
      if (!done(k)) return toast((i + 1) + '-savol uchun javob belgilanmagan');
      if (k.type === 'open') keys.push({ type: 'open', values: k.text.split(/[;|]/).map(s => s.trim()).filter(Boolean) });
      else keys.push({ type: 'choice', value: k.value });
    }
    sendBtn.disabled = true;
    try {
      const r = await fetch(cfg.endpoint, {
        method: cfg.method, headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, keys, options: state.options, math: state.math, initData: tg ? tg.initData : '', dev_user: dev }),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) { toast(data.detail || 'Xatolik yuz berdi'); sendBtn.disabled = false; return; }
      if (cfg.mode === 'admin') { location.href = cfg.redirect; return; }
      document.getElementById('footer').style.display = 'none';
      root.innerHTML = '<div class="notice"><b>✅ Test tuzildi</b>Kod: <b style="display:inline;font-size:28px">' + data.code + '</b><br>Test kodi botga ham yuborildi.</div>';
      if (tg) setTimeout(() => tg.close(), 2500);
    } catch (e) { toast('Tarmoq xatosi'); sendBtn.disabled = false; }
  });

  render();
})();

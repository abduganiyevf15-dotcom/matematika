(function () {
  const tg = window.Telegram && window.Telegram.WebApp;
  if (tg) { try { tg.ready(); tg.expand(); } catch (e) {} }
  const params = new URLSearchParams(location.search);
  const code = parseInt(params.get('code'), 10);
  const dev = params.get('dev_user');
  const L = ['A', 'B', 'C', 'D', 'E'];
  const ICON_DOC = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3" width="14" height="18" rx="3"/><path d="M9 8h6M9 12h6M9 16h4"/></svg>';
  const ICON_PEN = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';

  const app = document.getElementById('app');
  const footer = document.getElementById('footer');
  const keypad = document.getElementById('keypad');
  const sendBtn = document.getElementById('send');
  let test = null, answers = [], openMode = [], activeInput = null;

  function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.style.display = 'block';
    setTimeout(() => (t.style.display = 'none'), 3200);
  }
  function notice(title, text) {
    footer.style.display = 'none'; keypad.classList.remove('show');
    app.innerHTML = '<div class="notice"><b>' + title + '</b>' + text + '</div>';
  }
  function filled() { return answers.filter(a => a !== null && a !== '').length; }

  function updateProgress() {
    const n = filled();
    document.getElementById('prog-bar').style.width = (n * 100 / test.count) + '%';
    document.getElementById('prog-txt').textContent = n + ' / ' + test.count;
    answers.forEach((a, i) => {
      const el = document.getElementById('num' + i);
      if (el) el.classList.toggle('done', a !== null && a !== '');
    });
  }

  function render() {
    let html = '<div class="head"><div class="top"><div class="icon">' + ICON_DOC + '</div><div>' +
      '<h1></h1><div class="sub">Javoblaringizni belgilang</div></div></div>' +
      '<div class="chips"><span class="chip blue">Kod: ' + test.code + '</span><span class="chip">' + test.count + ' ta savol</span></div>' +
      '<div class="progress"><div class="bar"><i id="prog-bar" style="width:0"></i></div><span id="prog-txt">0 / ' + test.count + '</span></div></div>';
    if (test.open) {
      html += '<p class="hint">Variantni tanlang yoki <b>Ochiq javob</b> yozing. Katta-kichik harf farq qilmaydi.</p>';
    } else html += '<div style="height:14px"></div>';
    html += '<div class="rows">';
    for (let i = 0; i < test.count; i++) {
      html += '<div class="row"><div class="num" id="num' + i + '">' + (i + 1) + '</div>';
      for (let k = 0; k < test.options; k++) html += '<button class="opt" data-i="' + i + '" data-v="' + L[k].toLowerCase() + '">' + L[k] + '</button>';
      if (test.open) {
        html += '<div class="br"></div><button class="open-btn" data-open="' + i + '">' + ICON_PEN + 'Ochiq javob</button>';
        html += '<input class="open-input" id="in' + i + '" data-in="' + i + '" style="display:none" placeholder="Javobni yozing (masalan: 1/2)" inputmode="decimal" autocomplete="off">';
      }
      html += '</div>';
    }
    html += '</div>';
    app.innerHTML = html;
    app.querySelector('h1').textContent = test.title;
    footer.style.display = 'block';

    app.querySelectorAll('.opt').forEach(b => b.addEventListener('click', () => {
      const i = +b.dataset.i;
      answers[i] = answers[i] === b.dataset.v && !openMode[i] ? null : b.dataset.v;
      openMode[i] = false;
      syncRow(i);
      updateProgress();
    }));
    app.querySelectorAll('.open-btn').forEach(b => b.addEventListener('click', () => {
      const i = +b.dataset.open;
      openMode[i] = true;
      if (/^[a-e]$/.test(answers[i] || '')) answers[i] = null;
      syncRow(i);
      const inp = document.getElementById('in' + i);
      inp.focus();
      updateProgress();
    }));
    app.querySelectorAll('.open-input').forEach(inp => {
      inp.addEventListener('input', () => { answers[+inp.dataset.in] = inp.value.trim() || null; updateProgress(); });
      inp.addEventListener('focus', () => { activeInput = inp; keypad.classList.add('show'); });
    });
    updateProgress();
  }

  function syncRow(i) {
    document.querySelectorAll('.opt[data-i="' + i + '"]').forEach(b => b.classList.toggle('sel', !openMode[i] && answers[i] === b.dataset.v));
    const ob = document.querySelector('.open-btn[data-open="' + i + '"]');
    const inp = document.getElementById('in' + i);
    if (ob) ob.classList.toggle('sel', !!openMode[i]);
    if (inp) inp.style.display = openMode[i] ? 'block' : 'none';
  }

  // Matematik klaviatura
  ['1','2','3','4','5','6','7','8','9','0','.','/','-','⌫'].forEach(ch => {
    const b = document.createElement('button');
    b.textContent = ch;
    b.addEventListener('mousedown', e => e.preventDefault());
    b.addEventListener('click', () => {
      if (!activeInput) return;
      activeInput.value = ch === '⌫' ? activeInput.value.slice(0, -1) : activeInput.value + ch;
      activeInput.dispatchEvent(new Event('input'));
    });
    keypad.appendChild(b);
  });
  document.addEventListener('click', e => {
    if (!e.target.closest('.keypad') && !e.target.closest('.open-input')) keypad.classList.remove('show');
  });

  sendBtn.addEventListener('click', async () => {
    const left = test.count - filled();
    if (left > 0 && !confirm('Yana ' + left + ' ta savol javobsiz. Baribir yuborasizmi?')) return;
    sendBtn.disabled = true;
    try {
      const r = await fetch('/api/submit', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: test.code, answers, initData: tg ? tg.initData : '', dev_user: dev }),
      });
      const data = await r.json().catch(() => ({}));
      if (r.ok) {
        notice('✅ Yuborildi', 'Natijangiz bot orqali xabar qilinadi.');
        if (tg) setTimeout(() => tg.close(), 1400);
      } else {
        toast(data.message || data.detail || 'Xatolik yuz berdi');
        sendBtn.disabled = false;
      }
    } catch (e) { toast('Tarmoq xatosi'); sendBtn.disabled = false; }
  });

  async function init() {
    if (!code) return notice('Kod yo\'q', 'Test kodini botga yozing.');
    const r = await fetch('/api/test/' + code);
    if (!r.ok) return notice('Test topilmadi', 'Kod: ' + code);
    test = await r.json();
    if (!test.active) return notice('Test yopilgan', 'Bu testga javob berib bo\'lmaydi.');
    answers = new Array(test.count).fill(null);
    openMode = new Array(test.count).fill(false);
    render();
  }
  init();
})();

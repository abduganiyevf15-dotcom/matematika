# Test bot: Telegram bot + Mini App + Admin panel

O'quvchilar test javoblarini Telegram ichidagi web ilovada belgilaydi, bot natijani hisoblab yuboradi.
O'qituvchi testlarni admin paneldan (yoki botdan) boshqaradi.

## Imkoniyatlar
- Bot: test kodi (`13`), kalit bilan javob (`13*abcd...`), `Nomi+abcd...` bilan test tuzish
- Mini app: A–D / A–E tugmalari, ochiq javob, matematik klaviatura, progress
- Admin panel (`/admin`): testlar, natijalar, qayta topshirishga ruxsat, foydalanuvchilar
- Har bir testga bir marta javob berish

## Sozlamalar (environment o'zgaruvchilari)
`.env.example` ga qarang. Majburiylari: `BOT_TOKEN`, `BASE_URL` (HTTPS), `ADMIN_PASSWORD`.

## Mahalliy ishga tushirish
    pip install -r requirements.txt
    export BOT_TOKEN=... BASE_URL=https://... ADMIN_PASSWORD=...
    python server.py

## Docker
    docker build -t testbot .
    docker run -d -p 8000:8000 -v testbot-data:/data -e DB_PATH=/data/data.db \
      -e BOT_TOKEN=... -e BASE_URL=https://... -e ADMIN_PASSWORD=... testbot

## Railway / Render / Koyeb
GitHub reponi ulang, yuqoridagi o'zgaruvchilarni platforma sozlamasiga kiriting va
doimiy disk (volume) ulab `DB_PATH` ni shu diskka yo'naltiring, aks holda baza o'chib ketadi.

## Muhim
- Parolni almashtiring (standart: `admin123`).
- Tokenni hech qachon GitHub'ga yuklamang.
